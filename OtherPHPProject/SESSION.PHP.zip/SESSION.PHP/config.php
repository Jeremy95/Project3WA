<?php
/**
 * Created by PhpStorm.
 * User: wap19
 * Date: 19/02/15
 * Time: 09:29
 */
session_start();

$db = new PDO("mysql:host=localhost; dbname=chat", "root", "troiswa");
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
