/**
 * Created by wap19 on 19/01/15.
 */
$('#zoom').cycle({
    fx:    'shuffle', //Nom de de l'effet
    sync:  true,
    delay: -2000 //Determine le temps avant que sa commence
});